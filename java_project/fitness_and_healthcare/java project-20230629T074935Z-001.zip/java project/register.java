
package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

class register extends JFrame implements ActionListener {

	
	private static final long serialVersionUID = 1L;
	
	private Container c;
	private JLabel name;
	private JTextField tname;
	private JLabel pwd;
	private JTextField tpwd;
	private JLabel cpwd;
	private JTextField ctpwd;
	private JLabel gender;
	private JRadioButton male;
	private JRadioButton female;
	
	private ButtonGroup gengp;
	private JLabel dob;
	@SuppressWarnings("rawtypes")
	private JComboBox date;
	@SuppressWarnings("rawtypes")
	private JComboBox month;
	@SuppressWarnings("rawtypes")
	private JComboBox year;
	private JLabel add;
	private JTextArea tadd;
	private JCheckBox term;
	private JButton sub;
	private JButton reset;
	private JLabel res;

	private String dates[]
		= { "1", "2", "3", "4", "5",
			"6", "7", "8", "9", "10",
			"11", "12", "13", "14", "15",
			"16", "17", "18", "19", "20",
			"21", "22", "23", "24", "25",
			"26", "27", "28", "29", "30",
			"31" };
	private String months[]
		= { "Jan", "feb", "Mar", "Apr",
			"May", "Jun", "July", "Aug",
			"Sup", "Oct", "Nov", "Dec" };
	private String years[]
		= { "1995", "1996", "1997", "1998",
			"1999", "2000", "2001", "2002",
			"2003", "2004", "2005", "2006",
			"2007", "2008", "2009", "2010",
			"2011", "2012", "2013", "2014",
			"2015", "2016", "2017", "2018",
			"2019" };

	// constructor, to initialize the components
	// with default values.
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public register()
	{
		getContentPane().setBackground(Color.WHITE);
		setTitle("Registration Form");
		setBounds(300, 90, 900, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);

		c = getContentPane();
		c.setLayout(null);

		name = new JLabel("Name");
		name.setFont(new Font("Arial", Font.PLAIN, 20));
		name.setSize(100, 20);
		name.setLocation(275, 111);
		c.add(name);

		tname = new JTextField();
		tname.setFont(new Font("Arial", Font.PLAIN, 15));
		tname.setSize(190, 20);
		tname.setLocation(461, 113);
		c.add(tname);

		pwd = new JLabel("Password");
		pwd.setFont(new Font("Arial", Font.PLAIN, 20));
		pwd.setSize(100, 20);
		pwd.setLocation(275, 154);
		c.add(pwd);

		tpwd = new JPasswordField();
		tpwd.setFont(new Font("Arial", Font.PLAIN, 15));
		tpwd.setSize(190, 20);
		tpwd.setLocation(461, 196);
		c.add(tpwd);
		
		cpwd = new JLabel("Confirm Password");
		cpwd.setFont(new Font("Arial", Font.PLAIN, 20));
		cpwd.setSize(176, 20);
		cpwd.setLocation(275, 194);
		c.add(cpwd);

		ctpwd = new JPasswordField();
		ctpwd.setFont(new Font("Arial", Font.PLAIN, 15));
		ctpwd.setSize(190, 20);
		ctpwd.setLocation(461, 156);
		c.add(ctpwd);

		gender = new JLabel("Gender");
		gender.setFont(new Font("Arial", Font.PLAIN, 20));
		gender.setSize(100, 20);
		gender.setLocation(275, 225);
		c.add(gender);

		male = new JRadioButton("Male");
		male.setBackground(Color.WHITE);
		male.setFont(new Font("Arial", Font.PLAIN, 15));
		male.setSelected(true);
		male.setSize(75, 20);
		male.setLocation(576, 227);
		c.add(male);

		female = new JRadioButton("Female");
		female.setBackground(Color.WHITE);
		female.setFont(new Font("Arial", Font.PLAIN, 15));
		female.setSelected(false);
		female.setSize(80, 20);
		female.setLocation(461, 227);
		c.add(female);

		gengp = new ButtonGroup();
		gengp.add(male);
		gengp.add(female);

		dob = new JLabel("Date of Birth");
		dob.setFont(new Font("Arial", Font.PLAIN, 20));
		dob.setSize(153, 20);
		dob.setLocation(275, 279);
		c.add(dob);

		date = new JComboBox(dates);
		date.setFont(new Font("Arial", Font.PLAIN, 15));
		date.setSize(50, 20);
		date.setLocation(461, 269);
		c.add(date);

		month = new JComboBox(months);
		month.setFont(new Font("Arial", Font.PLAIN, 15));
		month.setSize(60, 20);
		month.setLocation(540, 269);
		c.add(month);

		year = new JComboBox(years);
		year.setFont(new Font("Arial", Font.PLAIN, 15));
		year.setSize(60, 20);
		year.setLocation(623, 269);
		c.add(year);

		add = new JLabel("Address");
		add.setFont(new Font("Arial", Font.PLAIN, 20));
		add.setSize(100, 20);
		add.setLocation(275, 318);
		c.add(add);

		tadd = new JTextArea();
		tadd.setBackground(SystemColor.inactiveCaptionBorder);
		tadd.setFont(new Font("Arial", Font.PLAIN, 15));
		tadd.setSize(200, 75);
		tadd.setLocation(461, 319);
		tadd.setLineWrap(true);
		c.add(tadd);

		term = new JCheckBox("Accept Terms And Conditions.");
		term.setBackground(Color.WHITE);
		term.setSelected(true);
		term.setFont(new Font("Arial", Font.PLAIN, 15));
		term.setSize(250, 20);
		term.setLocation(275, 413);
		c.add(term);

		sub = new JButton("Submit");
		sub.setBackground(SystemColor.controlHighlight);
		sub.setFont(new Font("Arial", Font.PLAIN, 15));
		sub.setSize(100, 20);
		sub.setLocation(447, 443);
		sub.addActionListener(new ActionListener() {

			@Override

			public void actionPerformed(ActionEvent e) {

			try

			{
				Class.forName("oracle.jdbc.driver.OracleDriver");

				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","Oracle123");

				PreparedStatement pst = con.prepareStatement("insert into register values(?,?,?,?)");

				pst.setString(1, tname.getText());

				pst.setString(2, tpwd.getText());

				pst.setString(3, ctpwd.getText());
				pst.setString(4, tadd.getText());

				if(tpwd.getText().equalsIgnoreCase(ctpwd.getText()))
				{
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null,"user registered successfully");
				login hd = new login();
				hd.setVisible(true);
				register window = new register();
				window.dispose();

				}


				else {
				JOptionPane.showMessageDialog(null,"Passwords do not match!!");


				}
				pst.close();
				}catch(Exception ee)
				{
				System.out.println(ee);
				}

				}

				});
		
		c.add(sub);

		reset = new JButton("Reset");
		reset.setBackground(SystemColor.controlHighlight);
		reset.setFont(new Font("Arial", Font.PLAIN, 15));
		reset.setSize(100, 20);
		reset.setLocation(623, 443);
		reset.addActionListener(this);
		c.add(reset);

		res = new JLabel("");
		res.setFont(new Font("Arial", Font.PLAIN, 20));
		res.setSize(500, 25);
		res.setLocation(100, 500);
		c.add(res);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\5.png"));
		lblNewLabel.setBounds(0, 0, 876, 552);
		getContentPane().add(lblNewLabel);
		
		JLabel pwd_1 = new JLabel("Password");
		pwd_1.setFont(new Font("Arial", Font.PLAIN, 20));
		pwd_1.setBounds(261, 194, 100, 20);
		getContentPane().add(pwd_1);
		pwd_1.setFont(new Font("Arial", Font.PLAIN, 20));

		setVisible(true);
	}

	// method actionPerformed()
	// to get the action performed
	// by the user and act accordingly
	@SuppressWarnings("null")
	public void actionPerformed(ActionEvent e)
	{
		JLabel tout = null;
		JLabel resadd = null;
		if (e.getSource() == sub) {
			if (term.isSelected()) {
				String data1;
				String data
					= "Name : "
					+ tname.getText() + "\n"
					+ "Mobile : "
					+ tpwd.getText() + "\n";
				if (male.isSelected())
					data1 = "Gender : Male"
							+ "\n";
				else
					data1 = "Gender : Female"
							+ "\n";
				String data2
					= "DOB : "
					+ (String)date.getSelectedItem()
					+ "/" + (String)month.getSelectedItem()
					+ "/" + (String)year.getSelectedItem()
					+ "\n";

				String data3 = "Address : " + tadd.getText();
				tout.setText(data + data1 + data2 + data3);
				tout.setFocusable(false);
				res.setText("Registration Successful..");
			}
			else {
				tout.setText("");
				resadd.setText("");
				res.setText("Please accept the"
							+ " terms & conditions..");
			}
		}

		else if (e.getSource() == reset) {
			String def = "";
			tname.setText(def);
			tadd.setText(def);
			res.setText(def);
			tout.setText(def);
			term.setSelected(false);
			date.setSelectedIndex(0);
			month.setSelectedIndex(0);
			year.setSelectedIndex(0);
			resadd.setText(def);
		}
	}
}

// Driver Code
class registeration {

	public static void main(String[] args) throws Exception
	{
		@SuppressWarnings("unused")
		register f = new register();
	}
}
