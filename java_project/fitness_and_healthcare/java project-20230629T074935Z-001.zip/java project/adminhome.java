package project;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;




import java.awt.event.MouseListener;
import java.io.File;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import java.awt.Font;

public class adminhome extends JFrame  {

	private static final long serialVersionUID = 1L;
	
	JFrame frame;
	JMenuBar menuBar;
	JMenu home;
	JMenu yoga;
	JMenu exercise;
	JMenu request;
	JFileChooser fileChooser;
	JMenuItem dietplan,workoutplan;
	JTextArea textArea;
	
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JTextField textField_1;
	private JTextField textField_2;
	private JLabel lblNewLabel4;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	public void mouse( )
	{
	addMouseListener((MouseListener) this);
	setSize(350,350);
	setVisible(true);
	}

	
	
	adminhome() {
		frame = new JFrame("Home Page");
		frame.getContentPane().setBackground(Color.WHITE);
		home = new JMenu("Home");
		yoga = new JMenu("Yoga");
		exercise = new JMenu("Exercise");
		request  = new JMenu("Add");
		textArea = new JTextArea();
		
		JMenuItem dp = new JMenuItem("Add diet plan");
		JMenuItem wp = new JMenuItem("Add workout plan");
		menuBar = new JMenuBar();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		request.add(dp);
		request.add(wp);
		
		menuBar.add(home);
		menuBar.add(yoga);
		menuBar.add(exercise);
		menuBar.add(request);
		
		frame.setJMenuBar(menuBar);
		
		home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
						new adminhome().setVisible(true);
						setVisible(false);
				
			}
		});
		
		
		yoga.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
						new adminhome().setVisible(true);
						setVisible(false);
				
			}
		});
		exercise.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
						new exercise().setVisible(true);
						setVisible(false);
				
			}
		});
		frame.setSize(800, 600);
		frame.getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("Add Yoga Posture");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(251, 56, 240, 46);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("Posture Name");
		lblNewLabel_2.setBounds(132, 201, 105, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(288, 195, 138, 20);
		frame.getContentPane().add(textField_1);
		
		lblNewLabel4 = new JLabel("Description");
		lblNewLabel4.setBounds(132, 256, 75, 17);
		frame.getContentPane().add(lblNewLabel4);
		
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(288, 253, 138, 20);
		frame.getContentPane().add(textField_2);
		
		btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

					try

					{

					Class.forName("oracle.jdbc.driver.OracleDriver");

					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","Oracle123");

					PreparedStatement pst = con.prepareStatement("insert into yoga(pose_name,description) values(?,?)");
					
					

					pst.setString(1, textField_1.getText());

					pst.setString(2, textField_2.getText());


					pst.executeUpdate();

					JOptionPane.showMessageDialog(null,"data entered successfully");

					new login().setVisible(true);

					setVisible(false);

					pst.close();

					}catch(Exception ee)

					{

					System.out.println(ee);

					}

					}

					});
		
		btnNewButton.setBounds(154, 348, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
	
		@SuppressWarnings("unused")
		class OpenListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				if (JFileChooser.APPROVE_OPTION == fileChooser.showOpenDialog(frame)) {
					File file = fileChooser.getSelectedFile();
					textArea.setText("");
					Scanner in = null;
					try {
						in = new Scanner(file);
						while(in.hasNext()) {
							String line = in.nextLine();
							textArea.append(line+"\n");
						}
					} catch (Exception ex) {
						ex.printStackTrace();
					} finally {
						in.close();
					}
				}
			}
		}
	
		
		btnNewButton_1 = new JButton("back");
		btnNewButton_1.setBounds(307, 348, 89, 23);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new login().setVisible(true);
				setVisible(false);
			}
		});
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\16.png"));
		lblNewLabel_4.setBounds(0, 0, 776, 530);
		frame.getContentPane().add(lblNewLabel_4);
		frame.setVisible(true);

	}
	
	
	
	public static void main(String args[]) {
		adminhome n = new adminhome();
			}



	


}


