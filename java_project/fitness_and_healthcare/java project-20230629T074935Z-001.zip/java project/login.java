package project;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
public class login extends JFrame {

	
	private static final long serialVersionUID = 1L;
	JFrame frame;
	private JTextField textField;
	private JPasswordField textField_1;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public login() {
		setBackground(Color.WHITE);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame =this;
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(50, 50, 800,624);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Username:");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(475, 177, 83, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel(" Password:");
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setBounds(475, 228, 83, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("login");
		btnNewButton.setBackground(UIManager.getColor("RadioButton.shadow"));
		btnNewButton.setForeground(new Color(128, 0, 64));
		btnNewButton.setBounds(542, 322, 70, 20);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");

					//step2 create the connection object

					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","Oracle123");

					Statement stmt=con.createStatement();
		
					@SuppressWarnings("deprecation")
					String query1="select * from register where name='"+textField.getText()+"' and password='"+textField_1.getText()+"'";
					ResultSet rs1=stmt.executeQuery(query1);
					if(rs1.next())
					{
						new adminhome().setVisible(true);
						setVisible(false);
					}
					
					
					else {
						JOptionPane.showMessageDialog(null,"login failed");
						
					}
				}catch(Exception e1)
				{
					System.out.println(e1);
				}
				
			}
		});
		frame.getContentPane().add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(575, 174, 104, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JPasswordField();
		textField_1.setToolTipText("");
		textField_1.setBounds(575, 225, 104, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		JCheckBox term = new JCheckBox("Remember Me");
		term.setBackground(Color.WHITE);
		term.setSelected(true);
		term.setFont(new Font("Arial", Font.PLAIN, 10));
		term.setSize(250, 14);
		term.setLocation(475, 278);
		frame.getContentPane().add(term);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\10.png"));
		lblNewLabel.setBounds(0, 0, 805, 481);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\9.png"));
		lblNewLabel_3.setBounds(386, 11, 356, 155);
		getContentPane().add(lblNewLabel_3);
		frame.setVisible(true);
	}
}